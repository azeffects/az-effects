# AZ Effects - pipeline version (single source of truth for the app version).
# The GitHub Actions workflow reads PIPELINE_VERSION from this file to tag releases.

PIPELINE_VERSION = "1.0"
