# AZ Effects v1.0 - Flask backend.
# Serves the dashboard + feature pages and exposes JSON APIs for projects,
# AI editing tools (captions, background removal, voice, TTS), ffmpeg
# filters/overlays/transitions, API keys, and the GitHub auto-updater.
#
# Heavy work always runs in background threads behind a job id, so the UI
# never freezes: POST returns {"job": "<id>"}, poll GET /api/job/<id>.

import asyncio
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import uuid

from flask import Flask, jsonify, request, send_from_directory
from werkzeug.utils import secure_filename

from pipeline import PIPELINE_VERSION
import updater

APP_NAME = "AZ Effects"
HOST = "127.0.0.1"
PORT = 8900

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 2 * 1024 * 1024 * 1024  # 2 GB uploads


# ---------------------------------------------------------------- paths

def resource_path(rel):
    """Path to a bundled resource (works in dev and in the PyInstaller exe)."""
    base = getattr(sys, "_MEIPASS", None) or os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base, rel)


def get_data_dir():
    local = os.environ.get("LOCALAPPDATA")
    if local:
        d = os.path.join(local, APP_NAME, "data")
    else:
        d = os.path.join(os.path.abspath("."), "data")
    os.makedirs(d, exist_ok=True)
    return d


DATA_DIR = None  # resolved lazily so tests can point LOCALAPPDATA at a tmp dir


def data_dir():
    global DATA_DIR
    if DATA_DIR is None:
        DATA_DIR = get_data_dir()
    return DATA_DIR


def uploads_dir():
    d = os.path.join(data_dir(), "uploads")
    os.makedirs(d, exist_ok=True)
    return d


def outputs_dir(job_id):
    d = os.path.join(data_dir(), "outputs", job_id)
    os.makedirs(d, exist_ok=True)
    return d


def ffmpeg_exe():
    import imageio_ffmpeg
    return imageio_ffmpeg.get_ffmpeg_exe()


# ---------------------------------------------------------------- jobs

JOBS = {}
JOBS_LOCK = threading.Lock()


def new_job(kind):
    jid = uuid.uuid4().hex[:8]
    with JOBS_LOCK:
        JOBS[jid] = {"id": jid, "kind": kind, "status": "running",
                     "progress": 0, "result": None, "error": None}
    return jid


def set_progress(jid, p):
    with JOBS_LOCK:
        if jid in JOBS:
            JOBS[jid]["progress"] = max(0, min(100, int(p)))


def finish_job(jid, result):
    with JOBS_LOCK:
        if jid in JOBS:
            JOBS[jid]["result"] = result
            JOBS[jid]["status"] = "done"
            JOBS[jid]["progress"] = 100


def fail_job(jid, err):
    with JOBS_LOCK:
        if jid in JOBS:
            JOBS[jid]["status"] = "error"
            JOBS[jid]["error"] = str(err)[:2000]


def run_bg(jid, fn):
    def _w():
        try:
            result = fn(lambda p: set_progress(jid, p))
            finish_job(jid, result)
        except Exception as e:  # noqa: BLE001 - surfaced to the UI as JSON
            fail_job(jid, e)

    threading.Thread(target=_w, daemon=True).start()


# ---------------------------------------------------------------- helpers

def save_upload(file_storage):
    jid = uuid.uuid4().hex[:8]
    name = secure_filename(file_storage.filename or "upload.bin") or "upload.bin"
    path = os.path.join(uploads_dir(), "{}_{}".format(jid, name))
    file_storage.save(path)
    return path


def run_ffmpeg(args):
    """Run ffmpeg, raise RuntimeError with a trimmed stderr on failure."""
    exe = ffmpeg_exe()
    p = subprocess.run([exe] + args, capture_output=True, text=True)
    if p.returncode != 0:
        tail = (p.stderr or "")[-2000:]
        raise RuntimeError("ffmpeg failed (code {}): {}".format(p.returncode, tail))
    return p


def probe_duration(path):
    """Return media duration in seconds (float) via ffmpeg -i parsing."""
    exe = ffmpeg_exe()
    p = subprocess.run([exe, "-i", path], capture_output=True, text=True)
    m = re.search(r"Duration: (\d+):(\d+):([\d.]+)", p.stderr or "")
    if not m:
        return 0.0
    h, mi, s = int(m.group(1)), int(m.group(2)), float(m.group(3))
    return h * 3600 + mi * 60 + s


def is_image(path):
    return os.path.splitext(path)[1].lower() in (".png", ".jpg", ".jpeg", ".webp", ".bmp")


def fmt_ts(seconds):
    ms = int(round(seconds * 1000))
    h, rem = divmod(ms, 3600000)
    m, rem = divmod(rem, 60000)
    s, ms = divmod(rem, 1000)
    return "{:02d}:{:02d}:{:02d},{:03d}".format(h, m, s, ms)


def segments_to_srt(segments):
    out = []
    for i, seg in enumerate(segments, 1):
        out.append(str(i))
        out.append("{} --> {}".format(fmt_ts(seg["start"]), fmt_ts(seg["end"])))
        out.append(seg["text"].strip())
        out.append("")
    return "\n".join(out)


def escape_drawtext(text):
    return (text.replace("\\", "\\\\").replace(":", "\\:").replace("'", "\\'")
                .replace("%", "\\%").replace("[", "\\[").replace("]", "\\]"))


def escape_subtitles(path):
    p = path.replace("\\", "/")
    return "'" + p.replace(":", "\\:").replace("'", "\\'") + "'"


# ---------------------------------------------------------------- pages

STATIC_DIR = resource_path("static")


@app.route("/")
def page_home():
    return send_from_directory(STATIC_DIR, "home.html")


@app.route("/captions")
def page_captions():
    return send_from_directory(STATIC_DIR, "captions.html")


@app.route("/bgremove")
def page_bgremove():
    return send_from_directory(STATIC_DIR, "bgremove.html")


@app.route("/voice")
def page_voice():
    return send_from_directory(STATIC_DIR, "voice.html")


@app.route("/effects")
def page_effects():
    return send_from_directory(STATIC_DIR, "effects.html")


@app.route("/settings")
def page_settings():
    return send_from_directory(STATIC_DIR, "settings.html")


@app.route("/api/health")
def api_health():
    return jsonify({"ok": True, "app": APP_NAME})


@app.route("/api/version")
def api_version():
    return jsonify({"version": PIPELINE_VERSION})


# ---------------------------------------------------------------- jobs

@app.route("/api/job/<jid>")
def api_job(jid):
    with JOBS_LOCK:
        job = JOBS.get(jid)
    if not job:
        return jsonify({"error": "Unknown job id"}), 404
    return jsonify(job)


@app.route("/api/file/<jid>/<name>")
def api_file(jid, name):
    d = os.path.join(data_dir(), "outputs", jid)
    return send_from_directory(d, secure_filename(name), as_attachment=False)


# ---------------------------------------------------------------- projects

def _projects_path():
    return os.path.join(data_dir(), "projects.json")


def _load_projects():
    p = _projects_path()
    if os.path.exists(p):
        try:
            with open(p, "r", encoding="utf-8") as f:
                data = json.load(f)
                return data if isinstance(data, list) else []
        except Exception:
            return []
    return []


def _save_projects(items):
    with open(_projects_path(), "w", encoding="utf-8") as f:
        json.dump(items, f, ensure_ascii=False, indent=2)


@app.route("/api/projects", methods=["GET"])
def api_projects_list():
    return jsonify(_load_projects())


@app.route("/api/projects", methods=["POST"])
def api_projects_add():
    body = request.get_json(force=True, silent=True) or {}
    name = (body.get("name") or "Untitled Project").strip()[:120]
    ptype = (body.get("type") or "video").strip()[:40]
    items = _load_projects()
    item = {"id": uuid.uuid4().hex[:8], "name": name, "type": ptype,
            "created": time.strftime("%Y-%m-%d %H:%M")}
    items.insert(0, item)
    _save_projects(items)
    return jsonify(item)


@app.route("/api/projects/<pid>", methods=["DELETE"])
def api_projects_delete(pid):
    items = [i for i in _load_projects() if i.get("id") != pid]
    _save_projects(items)
    return jsonify({"ok": True})


# ---------------------------------------------------------------- captions (faster-whisper)

def _transcribe_job(video_path, jid_out):
    def _fn(progress):
        try:
            from faster_whisper import WhisperModel
        except ImportError:
            raise RuntimeError("faster-whisper is not installed. "
                               "Run: pip install -r requirements.txt")
        model_root = os.path.join(data_dir(), "models")
        os.makedirs(model_root, exist_ok=True)
        progress(5)
        # "tiny" keeps the first-use download small (~75 MB).
        model = WhisperModel("tiny", download_root=model_root)
        progress(25)
        segments_iter, _info = model.transcribe(video_path, beam_size=5)
        segments = []
        for seg in segments_iter:
            segments.append({"start": round(seg.start, 2),
                             "end": round(seg.end, 2),
                             "text": seg.text.strip()})
        progress(85)
        out_dir = outputs_dir(jid_out)
        srt_path = os.path.join(out_dir, "captions.srt")
        with open(srt_path, "w", encoding="utf-8") as f:
            f.write(segments_to_srt(segments))
        progress(100)
        return {"srt": "captions.srt", "segments": segments,
                "download": "/api/file/{}/captions.srt".format(jid_out)}

    return _fn


@app.route("/api/captions", methods=["POST"])
def api_captions():
    f = request.files.get("video")
    if not f:
        return jsonify({"error": "No video file uploaded (field: video)."}), 400
    video_path = save_upload(f)
    jid = new_job("captions")
    run_bg(jid, _transcribe_job(video_path, jid))
    return jsonify({"job": jid})


@app.route("/api/captions/burn", methods=["POST"])
def api_captions_burn():
    video = request.files.get("video")
    srt = request.files.get("srt")
    if not video or not srt:
        return jsonify({"error": "Upload both 'video' and 'srt' files."}), 400
    video_path = save_upload(video)
    srt_path = save_upload(srt)

    def _fn(progress):
        out_dir = outputs_dir(new_job_id[0])
        out_path = os.path.join(out_dir, "captioned.mp4")
        progress(20)
        vf = "subtitles={}".format(escape_subtitles(srt_path))
        run_ffmpeg(["-y", "-i", video_path, "-vf", vf,
                    "-c:v", "libx264", "-pix_fmt", "yuv420p",
                    "-c:a", "aac", out_path])
        progress(100)
        return {"file": "captioned.mp4",
                "download": "/api/file/{}/captioned.mp4".format(new_job_id[0])}

    new_job_id = [None]
    jid = new_job("burn-captions")
    new_job_id[0] = jid
    run_bg(jid, _fn)
    return jsonify({"job": jid})


# ---------------------------------------------------------------- background removal (rembg)

@app.route("/api/bgremove", methods=["POST"])
def api_bgremove():
    f = request.files.get("image") or request.files.get("video")
    kind = "image" if request.files.get("image") else "video"
    if not f:
        return jsonify({"error": "No file uploaded (field: image)."}), 400
    if kind == "video":
        # Honest limitation: video background removal ships in v1.1.
        return jsonify({"error": "Video background removal is coming in v1.1. "
                                 "Please upload an image for now."}), 400
    src_path = save_upload(f)

    def _fn(progress):
        try:
            from rembg import remove
        except ImportError:
            raise RuntimeError("rembg is not installed. "
                               "Run: pip install -r requirements.txt")
        progress(10)
        from PIL import Image
        img = Image.open(src_path).convert("RGBA")
        progress(30)
        # u2net model downloads automatically on first use (~170 MB).
        out = remove(img)
        progress(80)
        out_dir = outputs_dir(jid_holder[0])
        out_path = os.path.join(out_dir, "no-bg.png")
        out.save(out_path)
        progress(100)
        return {"file": "no-bg.png",
                "download": "/api/file/{}/no-bg.png".format(jid_holder[0])}

    jid_holder = [None]
    jid = new_job("bgremove")
    jid_holder[0] = jid
    run_bg(jid, _fn)
    return jsonify({"job": jid})


# ---------------------------------------------------------------- TTS (edge-tts)

@app.route("/api/tts", methods=["POST"])
def api_tts():
    body = request.get_json(force=True, silent=True) or {}
    text = (body.get("text") or "").strip()
    voice = (body.get("voice") or "en-US-AriaNeural").strip()
    if not text:
        return jsonify({"error": "Empty text."}), 400
    if len(text) > 5000:
        return jsonify({"error": "Text too long (max 5000 chars)."}), 400

    def _fn(progress):
        try:
            import edge_tts
        except ImportError:
            raise RuntimeError("edge-tts is not installed. "
                               "Run: pip install -r requirements.txt")
        progress(15)
        out_dir = outputs_dir(jid_holder[0])
        out_path = os.path.join(out_dir, "speech.mp3")

        async def _gen():
            tts = edge_tts.Communicate(text, voice)
            await tts.save(out_path)

        asyncio.run(_gen())
        progress(100)
        return {"file": "speech.mp3",
                "download": "/api/file/{}/speech.mp3".format(jid_holder[0])}

    jid_holder = [None]
    jid = new_job("tts")
    jid_holder[0] = jid
    run_bg(jid, _fn)
    return jsonify({"job": jid})


# ---------------------------------------------------------------- voice changer (ffmpeg)

@app.route("/api/voicefx", methods=["POST"])
def api_voicefx():
    f = request.files.get("audio")
    if not f:
        return jsonify({"error": "No audio file uploaded (field: audio)."}), 400
    try:
        pitch = float(request.form.get("pitch", "1.0"))
        tempo = float(request.form.get("tempo", "1.0"))
    except ValueError:
        return jsonify({"error": "pitch/tempo must be numbers."}), 400
    if not (0.5 <= pitch <= 2.0 and 0.5 <= tempo <= 2.0):
        return jsonify({"error": "pitch and tempo must be between 0.5 and 2.0."}), 400
    src_path = save_upload(f)

    def _fn(progress):
        out_dir = outputs_dir(jid_holder[0])
        out_path = os.path.join(out_dir, "voicefx.mp3")
        progress(20)
        # asetrate changes pitch; aresample restores sample rate; atempo fixes speed.
        af = "asetrate=44100*{p},aresample=44100,atempo={t}".format(
            p=pitch, t=tempo / pitch)
        run_ffmpeg(["-y", "-i", src_path, "-af", af, "-c:a", "libmp3lame",
                    "-b:a", "192k", out_path])
        progress(100)
        return {"file": "voicefx.mp3",
                "download": "/api/file/{}/voicefx.mp3".format(jid_holder[0])}

    jid_holder = [None]
    jid = new_job("voicefx")
    jid_holder[0] = jid
    run_bg(jid, _fn)
    return jsonify({"job": jid})


# ---------------------------------------------------------------- ffmpeg filters

FILTERS = {
    "cinematic": "eq=contrast=1.12:saturation=1.3,unsharp=5:5:0.6",
    "grayscale": "hue=s=0",
    "warm": "colorbalance=rs=0.35:gs=0.12:bs=-0.25",
    "cool": "colorbalance=rs=-0.25:gs=0.05:bs=0.35",
    "vignette": "vignette=PI/4.5",
}


@app.route("/api/filter", methods=["POST"])
def api_filter():
    f = request.files.get("video")
    name = (request.form.get("filter") or "").strip().lower()
    if not f:
        return jsonify({"error": "No video file uploaded (field: video)."}), 400
    if name not in FILTERS:
        return jsonify({"error": "Unknown filter. Choose: {}".format(
            ", ".join(sorted(FILTERS)))}), 400
    src_path = save_upload(f)

    def _fn(progress):
        out_dir = outputs_dir(jid_holder[0])
        out_path = os.path.join(out_dir, "filtered.mp4")
        progress(20)
        run_ffmpeg(["-y", "-i", src_path, "-vf", FILTERS[name],
                    "-c:v", "libx264", "-pix_fmt", "yuv420p",
                    "-c:a", "aac", out_path])
        progress(100)
        return {"file": "filtered.mp4",
                "download": "/api/file/{}/filtered.mp4".format(jid_holder[0])}

    jid_holder = [None]
    jid = new_job("filter")
    jid_holder[0] = jid
    run_bg(jid, _fn)
    return jsonify({"job": jid})


# ---------------------------------------------------------------- text overlay

@app.route("/api/textoverlay", methods=["POST"])
def api_textoverlay():
    f = request.files.get("video")
    text = (request.form.get("text") or "").strip()
    position = (request.form.get("position") or "bottom").strip().lower()
    if not f:
        return jsonify({"error": "No video file uploaded (field: video)."}), 400
    if not text:
        return jsonify({"error": "Overlay text is empty."}), 400
    if position not in ("top", "middle", "bottom"):
        return jsonify({"error": "position must be top, middle or bottom."}), 400
    src_path = save_upload(f)

    # NOTE: the bundled static ffmpeg has no drawtext filter, so the overlay
    # is rendered with the libass "subtitles" filter from a generated SRT.
    # This works everywhere and needs no font file.
    align = {"top": 8, "middle": 5, "bottom": 2}[position]

    def _fn(progress):
        out_dir = outputs_dir(jid_holder[0])
        out_path = os.path.join(out_dir, "overlay.mp4")
        progress(15)
        dur = probe_duration(src_path) or 5.0
        srt_path = os.path.join(out_dir, "overlay.srt")
        with open(srt_path, "w", encoding="utf-8") as sf:
            sf.write("1\n{} --> {}\n{}\n".format(fmt_ts(0), fmt_ts(dur), text))
        progress(30)
        style = ("FontSize=30,Alignment={},Outline=2,BorderStyle=1,"
                 "MarginV=50").format(align)
        vf = "subtitles={}:force_style='{}'".format(escape_subtitles(srt_path), style)
        run_ffmpeg(["-y", "-i", src_path, "-vf", vf,
                    "-c:v", "libx264", "-pix_fmt", "yuv420p",
                    "-c:a", "aac", out_path])
        progress(100)
        return {"file": "overlay.mp4",
                "download": "/api/file/{}/overlay.mp4".format(jid_holder[0])}

    jid_holder = [None]
    jid = new_job("textoverlay")
    jid_holder[0] = jid
    run_bg(jid, _fn)
    return jsonify({"job": jid})


# ---------------------------------------------------------------- transitions (xfade)

TRANSITIONS = ("fade", "fadeblack", "fadewhite", "slideleft", "slideright",
               "smoothleft", "circleopen", "dissolve")


@app.route("/api/transition", methods=["POST"])
def api_transition():
    a = request.files.get("clip_a")
    b = request.files.get("clip_b")
    ttype = (request.form.get("type") or "fade").strip().lower()
    if not a or not b:
        return jsonify({"error": "Upload two clips (fields: clip_a, clip_b)."}), 400
    if ttype not in TRANSITIONS:
        return jsonify({"error": "Unknown transition. Choose: {}".format(
            ", ".join(TRANSITIONS))}), 400
    path_a = save_upload(a)
    path_b = save_upload(b)

    def _fn(progress):
        out_dir = outputs_dir(jid_holder[0])
        out_path = os.path.join(out_dir, "transition.mp4")
        progress(15)

        def _input_args(path):
            if is_image(path):
                return ["-loop", "1", "-t", "3", "-i", path], 3.0
            dur = probe_duration(path) or 3.0
            return ["-i", path], dur

        args_a, dur_a = _input_args(path_a)
        args_b, dur_b = _input_args(path_b)
        offset = max(0.1, dur_a - 1.0)
        total = dur_a + dur_b - 1.0
        norm = ("scale=1280:720:force_original_aspect_ratio=decrease,"
                "pad=1280:720:(ow-iw)/2:(oh-ih)/2,fps=30,format=yuv420p")
        fc = ("[0:v]{n}[v0];[1:v]{n}[v1];"
              "[v0][v1]xfade=transition={t}:duration=1:offset={o}[v]".format(
                  n=norm, t=ttype, o=offset))
        progress(30)
        run_ffmpeg(["-y"] + args_a + args_b +
                   ["-filter_complex", fc, "-map", "[v]",
                    "-map", "0:a?", "-t", str(total),
                    "-c:v", "libx264", "-pix_fmt", "yuv420p",
                    "-c:a", "aac", out_path])
        progress(100)
        return {"file": "transition.mp4",
                "download": "/api/file/{}/transition.mp4".format(jid_holder[0])}

    jid_holder = [None]
    jid = new_job("transition")
    jid_holder[0] = jid
    run_bg(jid, _fn)
    return jsonify({"job": jid})


# ---------------------------------------------------------------- API keys

KEY_SLOTS = [
    {"id": "whisper_api",
     "label": "Whisper API Key (optional)",
     "get_url": "https://platform.openai.com/api-keys",
     "guide": "Optional. Paste an OpenAI API key to use cloud transcription "
              "instead of the built-in local Whisper model."},
    {"id": "voice_clone",
     "label": "Voice Cloning Key",
     "get_url": "",
     "guide": "Coming soon - voice cloning ships in a later version."},
    {"id": "stock_music",
     "label": "Stock Music Key",
     "get_url": "",
     "guide": "Coming soon - licensed stock music ships in a later version."},
]


def _keys_path():
    return os.path.join(data_dir(), "api_keys.json")


def _load_keys():
    p = _keys_path()
    if os.path.exists(p):
        try:
            with open(p, "r", encoding="utf-8") as f:
                data = json.load(f)
                return data if isinstance(data, dict) else {}
        except Exception:
            return {}
    return {}


def _save_keys(d):
    with open(_keys_path(), "w", encoding="utf-8") as f:
        json.dump(d, f, indent=2)


@app.route("/api/keys", methods=["GET"])
def api_keys_list():
    stored = _load_keys()
    rows = []
    for slot in KEY_SLOTS:
        rows.append({"id": slot["id"], "label": slot["label"],
                     "get_url": slot["get_url"], "guide": slot["guide"],
                     "has_value": bool(stored.get(slot["id"]))})
    return jsonify(rows)


@app.route("/api/keys", methods=["POST"])
def api_keys_save():
    body = request.get_json(force=True, silent=True) or {}
    kid = (body.get("id") or "").strip()
    value = (body.get("value") or "").strip()
    if kid not in [s["id"] for s in KEY_SLOTS]:
        return jsonify({"error": "Unknown key id."}), 400
    stored = _load_keys()
    if value:
        stored[kid] = value
    else:
        stored.pop(kid, None)
    _save_keys(stored)
    return jsonify({"ok": True, "has_value": bool(value)})


# ---------------------------------------------------------------- auto-updater API

@app.route("/api/repo", methods=["GET"])
def api_repo_get():
    return jsonify({"repo": updater.get_repo()})


@app.route("/api/repo", methods=["POST"])
def api_repo_set():
    body = request.get_json(force=True, silent=True) or {}
    repo = (body.get("repo") or "").strip()
    if repo and "/" not in repo:
        return jsonify({"error": "Repo must look like: username/az-effects"}), 400
    p = os.path.join(data_dir(), "repo.json")
    if repo:
        with open(p, "w", encoding="utf-8") as f:
            json.dump({"repo": repo}, f)
    elif os.path.exists(p):
        os.remove(p)
    return jsonify({"ok": True, "repo": updater.get_repo()})


@app.route("/api/check-update", methods=["GET"])
def api_check_update():
    try:
        return jsonify(updater.check())
    except Exception as e:  # noqa: BLE001
        return jsonify({"error": str(e), "update_available": False})


@app.route("/api/download-update", methods=["POST"])
def api_download_update():
    try:
        info = updater.check()
    except Exception as e:  # noqa: BLE001
        return jsonify({"error": str(e)}), 500
    if info.get("error"):
        return jsonify({"error": info["error"]}), 400
    if not info.get("update_available"):
        return jsonify({"error": "You already have the latest version."}), 400
    url = info.get("url")
    if not url:
        return jsonify({"error": "No Setup.exe found in the latest release."}), 400
    latest = info.get("latest", "0")

    def _fn(progress):
        dest = os.path.join(tempfile.gettempdir(),
                             "AZEffects-Setup-v{}.exe".format(latest))

        def _cb(done, total):
            if total:
                progress(done * 90 // total)
            else:
                progress(50)

        updater.download(url, dest, _cb)
        progress(100)
        return {"file": os.path.basename(dest), "path": dest,
                "version": latest}

    jid = new_job("download-update")
    run_bg(jid, _fn)
    return jsonify({"job": jid})


@app.route("/api/update-progress", methods=["GET"])
def api_update_progress():
    jid = request.args.get("job", "")
    with JOBS_LOCK:
        job = JOBS.get(jid)
    if not job:
        return jsonify({"error": "Unknown job id"}), 404
    return jsonify({"status": job["status"], "progress": job["progress"],
                    "error": job["error"], "result": job["result"]})


@app.route("/api/launch-update", methods=["POST"])
def api_launch_update():
    body = request.get_json(force=True, silent=True) or {}
    jid = body.get("job", "")
    with JOBS_LOCK:
        job = JOBS.get(jid)
    if not job or job["status"] != "done":
        return jsonify({"error": "Download not finished yet."}), 400
    path = (job["result"] or {}).get("path")
    if not path or not os.path.exists(path):
        return jsonify({"error": "Downloaded file not found."}), 400
    try:
        updater.launch_installer(path)
    except Exception as e:  # noqa: BLE001
        return jsonify({"error": str(e)}), 500
    return jsonify({"ok": True})


# ---------------------------------------------------------------- errors

@app.errorhandler(404)
def _404(_e):
    return jsonify({"error": "Not found"}), 404


@app.errorhandler(413)
def _413(_e):
    return jsonify({"error": "File too large (max 2 GB)."}), 413


@app.errorhandler(500)
def _500(_e):
    return jsonify({"error": "Internal server error."}), 500


if __name__ == "__main__":
    app.run(host=HOST, port=PORT, threaded=True)
