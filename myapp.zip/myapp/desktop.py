# AZ Effects - desktop entry point (PyInstaller target).
# Starts the Flask backend in a background thread, then opens the
# PyWebView window. The window is a normal (not frameless) window.
# The Flask server runs in a daemon thread, so closing the window
# ends the whole process, including the server.

import threading
import time

import webview

from app import app

HOST = "127.0.0.1"
PORT = 8900


def _run_server():
    app.run(host=HOST, port=PORT, threaded=True, use_reloader=False)


def main():
    t = threading.Thread(target=_run_server, daemon=True)
    t.start()
    # Give the server a moment to bind before the window loads.
    time.sleep(1.0)
    webview.create_window("AZ Effects", "http://{}:{}".format(HOST, PORT),
                          width=1280, height=800)
    webview.start()


if __name__ == "__main__":
    main()
