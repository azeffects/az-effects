# AZ Effects - auto-updater.
# Checks GitHub releases for a newer version, downloads the new Setup.exe
# with progress, and can launch the installer. Used by app.py and standalone.

import json
import os
import urllib.request
import urllib.error

# Default repository. The user replaces YOUR_GITHUB_USERNAME with their own
# GitHub username after creating the repo. Can be overridden at runtime via
# data/repo.json -> {"repo": "username/az-effects"} (fallback rule).
REPO = "YOUR_GITHUB_USERNAME/az-effects"


def _data_dir():
    local = os.environ.get("LOCALAPPDATA")
    if local:
        d = os.path.join(local, "AZ Effects", "data")
    else:
        d = os.path.join(os.path.abspath("."), "data")
    return d


def get_repo():
    """Return the effective repo slug, honoring the data/repo.json override."""
    try:
        p = os.path.join(_data_dir(), "repo.json")
        if os.path.exists(p):
            with open(p, "r", encoding="utf-8") as f:
                repo = (json.load(f) or {}).get("repo", "").strip()
                if repo:
                    return repo
    except Exception:
        pass
    return REPO


def _parse_version(v):
    parts = []
    for chunk in str(v).strip().lstrip("v").split("."):
        num = "".join(ch for ch in chunk if ch.isdigit())
        parts.append(int(num) if num else 0)
    return parts


def is_newer(latest, current):
    """True if latest version string is newer than current."""
    a, b = _parse_version(latest), _parse_version(current)
    n = max(len(a), len(b))
    a += [0] * (n - len(a))
    b += [0] * (n - len(b))
    return a > b


def check():
    """Query the latest GitHub release and compare with the local version.

    Returns dict: {"update_available": bool, "latest": str, "url": str|None,
                   "repo": str} or {"error": str} on failure.
    """
    from pipeline import PIPELINE_VERSION

    repo = get_repo()
    if "YOUR_GITHUB_USERNAME" in repo:
        return {"error": "GitHub repo not configured yet. Set it in Settings.",
                "update_available": False, "latest": PIPELINE_VERSION,
                "url": None, "repo": repo}
    url = "https://api.github.com/repos/{}/releases/latest".format(repo)
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "AZ-Effects-Updater"})
        with urllib.request.urlopen(req, timeout=15) as r:
            data = json.load(r)
    except Exception as e:
        return {"error": "Could not reach GitHub: {}".format(e),
                "update_available": False, "latest": PIPELINE_VERSION,
                "url": None, "repo": repo}

    tag = str(data.get("tag_name", "") or "")
    latest = tag.lstrip("v") or PIPELINE_VERSION
    dl_url = None
    for asset in data.get("assets", []) or []:
        name = str(asset.get("name", ""))
        if name.lower().endswith(".exe"):
            dl_url = asset.get("browser_download_url")
            break
    return {
        "update_available": is_newer(latest, PIPELINE_VERSION),
        "latest": latest,
        "url": dl_url,
        "repo": repo,
    }


def download(url, dest, progress_cb=None):
    """Stream-download a file, calling progress_cb(downloaded, total)."""
    req = urllib.request.Request(url, headers={"User-Agent": "AZ-Effects-Updater"})
    with urllib.request.urlopen(req, timeout=60) as r:
        total = int(r.headers.get("Content-Length") or 0)
        downloaded = 0
        os.makedirs(os.path.dirname(os.path.abspath(dest)), exist_ok=True)
        with open(dest, "wb") as f:
            while True:
                chunk = r.read(1024 * 256)
                if not chunk:
                    break
                f.write(chunk)
                downloaded += len(chunk)
                if progress_cb:
                    try:
                        progress_cb(downloaded, total)
                    except Exception:
                        pass
    return dest


def launch_installer(path):
    """Launch the downloaded Setup.exe (Windows)."""
    if os.name == "nt":
        os.startfile(os.path.abspath(path))  # noqa: S606 - local installer the user requested
    else:
        raise RuntimeError("Installer launch is only supported on Windows.")
